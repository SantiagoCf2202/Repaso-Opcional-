namespace Lados_del_triangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Santiago Cano Florez 
        /// 23/03/2023
        /// Pulir las habilidades de logica y uso de windows forms
        /// </summary>
        
        // Colocamos a leer los dos texbox qu son los 2 catetos del triangulo y haciendo uso de pitagoras damos la respuesta la hipotenusa
        private void button1_Click(object sender, EventArgs e)
        {
            double cateto1 = double.Parse(textBoxCateto1.Text);
            double cateto2 = double.Parse(textBoxCateto2.Text);
            double hipotenusa = Math.Sqrt(cateto1 * cateto1 + cateto2 * cateto2);
            textBoxHipotenusa.Text = hipotenusa.ToString();
        }
    }
}