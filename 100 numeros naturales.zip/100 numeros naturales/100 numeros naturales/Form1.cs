namespace _100_numeros_naturales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Santiago Cano Florez
        /// 23/03/2023
        /// Ejercicios para pulir y mejrar la logica y uso de windows forms
        /// </summary>

        //Hacemos uso de un ciclo ford en aumento de 1 hasta 100 y los mostramos en la lista 
        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 1; i <= 100; i++)
            {
                listBoxNumeros.Items.Add(i);
            }
        }
    }
}