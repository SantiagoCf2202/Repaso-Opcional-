namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Santiago Cano Florez
        /// 23/03/2023
        /// Hacer un poco de practica para pulir la logica y manejo de windows forms
        /// <summary>


        //Aca elegi el comando de las teclas del teclado para que el usuario solo pueda digitar solo numeros 
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >=32 && e.KeyChar <44) || (e.KeyChar >= 58 && e.KeyChar <= 225))
            {
                MessageBox.Show("Solo numeros!!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Handled = true;
                return;
            }

        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        // En sta parte colocamos las condiciones y que se muestre segun lo cumplido, que el numero si es mayor a cero y la funcion para saber si el numero es par o impar
        private void button1_Click(object sender, EventArgs e)
        {
            double N;
            N=Convert.ToDouble(textBox1.Text);

            if (N > 0 )
            {
                MessageBox.Show("El numero es positivo");
            }
            else
            {
                MessageBox.Show("El numero es negativo");

            }
            if (N % 2 == 0)
            {
                MessageBox.Show("El numero es par");
            }
            else
            {
                MessageBox.Show("El numero es impar");
            }
        }
    }
}