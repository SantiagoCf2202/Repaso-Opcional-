namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >=32 && e.KeyChar <44) || (e.KeyChar >= 58 && e.KeyChar <= 225))
            {
                MessageBox.Show("Solo numeros!!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Handled = true;
                return;
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double N;
            N=Convert.ToDouble(textBox1.Text);

            if (N > 0 )
            {
                MessageBox.Show("El numero es positivo");
            }
            else
            {
                MessageBox.Show("El numero es negativo");

            }
            if (N % 2 == 0)
            {
                MessageBox.Show("El numero es par");
            }
            else
            {
                MessageBox.Show("El numero es impar");
            }
        }
    }
}